<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ytp`;");
E_C("CREATE TABLE `ytp` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YBH` varchar(10) NOT NULL,
  `YFL` varchar(3) NOT NULL,
  `YXT` varchar(100) NOT NULL,
  `YDT` varchar(100) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`),
  KEY `YLX` (`YLX`),
  KEY `YBH` (`YBH`),
  KEY `YFL` (`YFL`)
) ENGINE=MyISAM AUTO_INCREMENT=1066012 DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>