<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ytg`;");
E_C("CREATE TABLE `ytg` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YBT` varchar(50) NOT NULL,
  `YNR` text NOT NULL,
  `YRQ` int(10) NOT NULL,
  `YCS` int(10) NOT NULL,
  `YTT` int(10) NOT NULL,
  `YZT` varchar(2) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`),
  KEY `YZT` (`YZT`)
) ENGINE=MyISAM AUTO_INCREMENT=1004461 DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>