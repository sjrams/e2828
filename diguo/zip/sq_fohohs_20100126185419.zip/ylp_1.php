<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ylp`;");
E_C("CREATE TABLE `ylp` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YMC` varchar(20) NOT NULL,
  `YFW` varchar(5) NOT NULL,
  `YXX` varchar(50) NOT NULL,
  `YKF` varchar(30) NOT NULL,
  `YDZ` varchar(50) NOT NULL,
  `YDH` varchar(30) NOT NULL,
  `YLX` varchar(10) NOT NULL,
  `YBZ` varchar(4) NOT NULL,
  `YHX` varchar(20) NOT NULL,
  `YJG` varchar(20) NOT NULL,
  `YKP` varchar(20) NOT NULL,
  `YJF` varchar(20) NOT NULL,
  `YZD` varchar(20) NOT NULL,
  `YJZ` varchar(20) NOT NULL,
  `YRJ` varchar(10) NOT NULL,
  `YLH` varchar(10) NOT NULL,
  `YZH` varchar(10) NOT NULL,
  `YJT` varchar(250) NOT NULL,
  `YZB` varchar(250) NOT NULL,
  `YNB` varchar(250) NOT NULL,
  `YJS` text NOT NULL,
  `YTP` varchar(100) NOT NULL default 'no.jpg',
  `YSP` varchar(100) NOT NULL default 'http://www.fcwlm.cn/no.flv',
  `YPX` int(2) NOT NULL default '0',
  `YRQ` int(10) NOT NULL,
  `YCS` int(10) NOT NULL default '0',
  `YZT` varchar(2) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`),
  KEY `YPX` (`YPX`),
  KEY `YZT` (`YZT`)
) ENGINE=MyISAM AUTO_INCREMENT=1004814 DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>