<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ycs`;");
E_C("CREATE TABLE `ycs` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YLX` varchar(4) NOT NULL,
  `YXX` varchar(15) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YLX` (`YLX`)
) ENGINE=MyISAM AUTO_INCREMENT=1004956 DEFAULT CHARSET=gbk");
E_D("replace into `ycs` values('1004949','1917','��������','ƽ��');");
E_D("replace into `ycs` values('1004950','1917','��������','����');");
E_D("replace into `ycs` values('1004952','1917','��������','�ʹ�');");

require("../../inc/footer.php");
?>