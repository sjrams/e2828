<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `yly`;");
E_C("CREATE TABLE `yly` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YXM` varchar(10) NOT NULL,
  `YDH` varchar(30) NOT NULL,
  `YSJ` varchar(30) NOT NULL,
  `YQQ` varchar(10) NOT NULL,
  `YNR` text NOT NULL,
  `YRQ` int(10) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`)
) ENGINE=MyISAM AUTO_INCREMENT=1072173 DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>