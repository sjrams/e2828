<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ylj`;");
E_C("CREATE TABLE `ylj` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YWZ` varchar(7) NOT NULL,
  `YTP` varchar(18) NOT NULL,
  `YDZ` varchar(100) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YLX` (`YLX`)
) ENGINE=MyISAM AUTO_INCREMENT=1006457 DEFAULT CHARSET=gbk");
E_D("replace into `ylj` values('1006456','1917','ͼƬ','�ں�������̳','1264102664624.gif','http://www.foho8.com');");
E_D("replace into `ylj` values('1006454','1917','����','�ں�������̳','no.gif','http://www.foho8.com');");
E_D("replace into `ylj` values('1006455','1917','ͼƬ','�ں�������','1264102635253.gif','http://www.fnhoo.com');");

require("../../inc/footer.php");
?>