<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ylj`;");
E_C("CREATE TABLE `ylj` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YWZ` varchar(7) NOT NULL,
  `YTP` varchar(18) NOT NULL,
  `YDZ` varchar(100) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YLX` (`YLX`)
) ENGINE=MyISAM AUTO_INCREMENT=1006454 DEFAULT CHARSET=gbk");
E_D("replace into `ylj` values('1004058','1917','ͼƬ','100Դ��','1253087219751.gif','http://www.100ym.com/');");
E_D("replace into `ylj` values('1006453','1917','����','����������','no.gif','http://www.jingmen.gov.cn/');");
E_D("replace into `ylj` values('1006445','1917','����','װ����','no.gif','http://www.3dkk.com/');");
E_D("replace into `ylj` values('1006451','1917','����','���ŷ�����','no.gif','http://www.fdcjm.com/');");
E_D("replace into `ylj` values('1006452','1917','����','�人�ڷ���','no.gif','http://www.fdc.com.cn/');");

require("../../inc/footer.php");
?>