<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `yxq`;");
E_C("CREATE TABLE `yxq` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YFW` varchar(5) NOT NULL,
  `YDD` varchar(15) NOT NULL,
  `YFX` varchar(3) NOT NULL,
  `YHX` varchar(10) NOT NULL,
  `YLC` varchar(10) NOT NULL,
  `YMJ` varchar(20) NOT NULL,
  `YZX` varchar(4) NOT NULL,
  `YCK` varchar(20) NOT NULL,
  `YPT` varchar(40) NOT NULL,
  `YJG` varchar(20) NOT NULL,
  `YBZ` varchar(250) NOT NULL,
  `YRQ` int(10) NOT NULL,
  `YCS` int(10) NOT NULL default '0',
  `YZT` varchar(2) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`),
  KEY `YLX` (`YLX`),
  KEY `YZT` (`YZT`)
) ENGINE=MyISAM AUTO_INCREMENT=1064666 DEFAULT CHARSET=gbk");
E_D("replace into `yxq` values('1062293','1917','1423747','��','����','','�׷�','','3-8','100-140','��װ��','','����,������,','','','1250824711','28','����');");
E_D("replace into `yxq` values('1064665','1917','1435600','��','������','�󹺵Ǽ��󹺵Ǽ�','����','�󹺵Ǽ�','5','123','װ�޲���','�󹺵Ǽ�','����,','','�󹺵Ǽ��󹺵Ǽ�','1253096812','2','����');");

require("../../inc/footer.php");
?>