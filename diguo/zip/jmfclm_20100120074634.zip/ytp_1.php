<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ytp`;");
E_C("CREATE TABLE `ytp` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YBH` varchar(10) NOT NULL,
  `YFL` varchar(3) NOT NULL,
  `YXT` varchar(100) NOT NULL,
  `YDT` varchar(100) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YYH` (`YYH`),
  KEY `YLX` (`YLX`),
  KEY `YBH` (`YBH`),
  KEY `YFL` (`YFL`)
) ENGINE=MyISAM AUTO_INCREMENT=1066012 DEFAULT CHARSET=gbk");
E_D("replace into `ytp` values('1057602','1917','1414099','¥��','1004561','Ч��ͼ','2009/s/1249727511704.jpg','2009/b/1249727511704.jpg');");
E_D("replace into `ytp` values('1057603','1917','1414099','¥��','1004561','Ч��ͼ','2009/s/1249727530374.jpg','2009/b/1249727530374.jpg');");
E_D("replace into `ytp` values('1057604','1917','1414099','¥��','1004561','Ч��ͼ','2009/s/1249727545601.jpg','2009/b/1249727545601.jpg');");

require("../../inc/footer.php");
?>