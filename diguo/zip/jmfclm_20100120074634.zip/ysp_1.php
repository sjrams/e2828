<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ysp`;");
E_C("CREATE TABLE `ysp` (
  `YID` int(10) NOT NULL auto_increment,
  `YZM` int(4) NOT NULL,
  `YBH` int(2) NOT NULL default '0',
  `YMC` varchar(20) NOT NULL,
  `YSP` varchar(100) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YZM` (`YZM`),
  KEY `YBH` (`YBH`)
) ENGINE=MyISAM AUTO_INCREMENT=1000278 DEFAULT CHARSET=gbk");
E_D("replace into `ysp` values('1000161','1879','8','ͩ��ڶ��ڿ�����','http://www.txfc.net/flv/1240620679720.flv');");
E_D("replace into `ysp` values('1000003','1895','0','����ʱ����԰','http://www.lxfcw.cn/flv/1232641597312.flv');");
E_D("replace into `ysp` values('1000004','1895','0','����ʱ����԰','http://www.lxfcw.cn/flv/1232642088320.flv');");
E_D("replace into `ysp` values('1000128','1878','0','������Է������Ԣ����','http://www.phfc.net/flv/1238240498651.flv');");
E_D("replace into `ysp` values('1000263','1810','4','����˹�մ�','http://www.daffc.cn/flv/1249347528155.flv');");
E_D("replace into `ysp` values('1000230','207','1','��������','http://www.chufc.cn/flv/1246648929934.flv');");
E_D("replace into `ysp` values('1000012','1868','5','�������','http://www.yqfcw.cn/flv/1232702254911.flv');");
E_D("replace into `ysp` values('1000122','1810','1','�������1','http://www.daffc.cn/flv/1238138731161.flv');");
E_D("replace into `ysp` values('1000192','1488','50','zylfy','http://www.dsqfcw.com/flv/1243724906992.flv');");
E_D("replace into `ysp` values('1000016','1868','4','���嶫����Ӥ','http://www.yqfcw.cn/flv/1232775632808.flv');");
E_D("replace into `ysp` values('1000020','1828','0','�����㾰','http://www.jrfcw.com/flv/1233053307579.flv');");
E_D("replace into `ysp` values('1000141','321','1','����Ҫ�ļ�','http://www.guifc.cn/flv/1248873382194.flv');");
E_D("replace into `ysp` values('1000236','279','1','1111','http://www.enfcw.cn/flv/1247026945921.flv');");
E_D("replace into `ysp` values('1000228','1839','1','��վ������Ƶ','http://www.sihfc.cn/flv/1246117131143.flv');");
E_D("replace into `ysp` values('1000206','364','0','����','http://www.gafcw.cn/flv/1244625625946.flv');");
E_D("replace into `ysp` values('1000227','1839','0','��г����','http://www.sihfc.cn/flv/1246117060882.flv');");
E_D("replace into `ysp` values('1000029','128','0','������Ƶ','http://www.eedsf.cn/flv/1233546126421.flv');");
E_D("replace into `ysp` values('1000031','1813','0','���л�԰','http://www.fnfcw.cn/flv/1233640058109.flv');");
E_D("replace into `ysp` values('1000034','1813','0','�غ���ó�㳡(��)','http://www.fnfcw.cn/flv/1233667072901.flv');");
E_D("replace into `ysp` values('1000134','1803','0','123','http://www.lshfc.cn/flv/1238478678188.flv');");
E_D("replace into `ysp` values('1000040','178','0','����������','http://www.hanfc.cn/flv/1233976192702.flv');");
E_D("replace into `ysp` values('1000041','178','0','��Դ��Է','http://www.hanfc.cn/flv/1233976233169.flv');");
E_D("replace into `ysp` values('1000042','178','0','�������㳡','http://www.hanfc.cn/flv/1233977512746.flv');");
E_D("replace into `ysp` values('1000043','178','0','�ൺ���','http://www.hanfc.cn/flv/1233977550317.flv');");
E_D("replace into `ysp` values('1000044','1868','3','��Ӥ��Ƶ','http://www.yqfcw.cn/flv/1234014616846.flv');");
E_D("replace into `ysp` values('1000149','1880','0','��������','http://www.jsfc.net.cn/flv/1239462460491.flv');");
E_D("replace into `ysp` values('1000046','2047','0','��վ���','http://www.chlfc.cn/flv/1234427103248.flv');");
E_D("replace into `ysp` values('1000111','1879','3','�ƽ�۰�','http://www.txfc.net/flv/1237970748259.flv');");
E_D("replace into `ysp` values('1000277','1765','0','Ů��','http://www.snfce.cn/flv/1252576086598.flv');");
E_D("replace into `ysp` values('1000051','1820','0','��֮��','http://www.gaoyfc.cn/flv/1235099317703.flv');");
E_D("replace into `ysp` values('1000052','1820','0','�µر�','http://www.gaoyfc.cn/flv/1235099449240.flv');");
E_D("replace into `ysp` values('1000234','207','2','��ʢ����','http://www.chufc.cn/flv/1246976417326.flv');");
E_D("replace into `ysp` values('1000148','142','0','�����ʻ�԰','http://www.ykouf.cn/flv/1239338212141.flv');");
E_D("replace into `ysp` values('1000060','1797','0','���Ǿ���','http://www.gyfce.cn/flv/1235532135170.flv');");
E_D("replace into `ysp` values('1000178','2005','0','��ɽ��԰','http://www.xiaofdc.cn/flv/1242777746743.flv');");
E_D("replace into `ysp` values('1000063','334','0','���Ϸ���','http://www.sanfc.cn/flv/1235622435240.flv');");
E_D("replace into `ysp` values('1000064','334','0','���ǳ�����Ƭ','http://www.sanfc.cn/flv/1235626297971.flv');");
E_D("replace into `ysp` values('1000156','249','5','������Ӱ��','http://www.zhzhfc.cn/flv/1239878611431.flv');");
E_D("replace into `ysp` values('1000180','189','2','���ؽ�̲','http://www.sxfce.com/flv/1242907390680.flv');");
E_D("replace into `ysp` values('1000094','208','0','ŷ��','http://www.lanfc.cn/flv/1237020129698.flv');");
E_D("replace into `ysp` values('1000071','1846','0','���ҷ�չ�ĸ�ί������������','http://www.xsfce.cn/flv/1235736851413.flv');");
E_D("replace into `ysp` values('1000072','2292','0','��Ʒ�Ƽ�','http://www.zcfcw.cn/flv/1235974964504.flv');");
E_D("replace into `ysp` values('1000075','2015','0','����չʾ','http://www.shoufc.cn/flv/1236055080465.flv');");
E_D("replace into `ysp` values('1000076','3084','0','����������','http://www.emfcw.cn/flv/1236094936212.flv');");
E_D("replace into `ysp` values('1000078','1846','0','�¼ұ����ڶ���ס�������״ι����Ż�����','http://www.xsfce.cn/flv/1236245460231.flv');");
E_D("replace into `ysp` values('1000079','1803','0','123','http://www.lshfc.cn/flv/1236427076741.flv');");
E_D("replace into `ysp` values('1000081','1868','2','����','http://www.yqfcw.cn/flv/1236595907704.flv');");
E_D("replace into `ysp` values('1000082','2622','0','leidi','http://www.wcfcw.com/flv/1236615576624.flv');");
E_D("replace into `ysp` values('1000083','334','0','�������ϳ�','http://www.sanfc.cn/flv/1236644633354.flv');");
E_D("replace into `ysp` values('1000084','1868','1','����2','http://www.yqfcw.cn/flv/1236693236267.flv');");
E_D("replace into `ysp` values('1000087','265','0','������Է','http://www.zmdfcw.cn/flv/1236926151533.flv');");
E_D("replace into `ysp` values('1000160','1771','4','�����㾰','http://www.liyfc.cn/flv/1240459365946.flv');");
E_D("replace into `ysp` values('1000140','194','1','������Ƶ','http://www.lsfce.com/flv/1238721647655.flv');");
E_D("replace into `ysp` values('1000132','358','0','��Ϫ�غ��͵ذ�','http://www.suinf.cn/flv/1238399500723.flv');");
E_D("replace into `ysp` values('1000104','1813','1','����ŷ�޻�԰','http://www.fnfcw.cn/flv/1237783250460.flv');");
E_D("replace into `ysp` values('1000146','172','0','����Է','http://www.wuxifc.cn/flv/1239247083821.flv');");
E_D("replace into `ysp` values('1000235','207','1','��ʢ����','http://www.chufc.cn/flv/1246976557189.flv');");
E_D("replace into `ysp` values('1000159','1771','6','����Է','http://www.liyfc.cn/flv/1240459299825.flv');");
E_D("replace into `ysp` values('1000276','1765','1','�鱦','http://www.snfce.cn/flv/1252574227796.flv');");
E_D("replace into `ysp` values('1000124','2336','0','���巿������Ƶ���','http://www.lqfce.cn/flv/1238163127870.flv');");
E_D("replace into `ysp` values('1000106','1813','3','���л�԰','http://www.fnfcw.cn/flv/1237818451545.flv');");
E_D("replace into `ysp` values('1000105','1813','2','�غ���ó�㳡','http://www.fnfcw.cn/flv/1237783347186.flv');");
E_D("replace into `ysp` values('1000119','311','0','�����׸�','http://www.hefcw.cn/flv/1238127681253.flv');");
E_D("replace into `ysp` values('1000123','1899','0','1','http://www.wyfce.cn/flv/1238144705563.flv');");
E_D("replace into `ysp` values('1000176','1761','0','���','http://www.pzfcw.cn/flv/1247540421778.flv');");
E_D("replace into `ysp` values('1000268','1787','0','��','http://www.rgfcw.cn/flv/1249877581231.flv');");
E_D("replace into `ysp` values('1000125','2015','0','������԰','http://www.shoufc.cn/flv/1238231502560.flv');");
E_D("replace into `ysp` values('1000112','1879','5','��������','http://www.txfc.net/flv/1237970911454.flv');");
E_D("replace into `ysp` values('1000110','1879','4','�޳ɡ���ݺ��԰','http://www.txfc.net/flv/1237970548880.flv');");
E_D("replace into `ysp` values('1000239','1771','2','������ͥ','http://www.liyfc.cn/flv/1247150730229.flv');");
E_D("replace into `ysp` values('1000207','146','1','��������','http://www.tiefc.cn/flv/1244632213542.flv');");
E_D("replace into `ysp` values('1000107','189','1','���ͣ�ɽˮ�˼�','http://www.sxfce.com/flv/1237862750798.flv');");
E_D("replace into `ysp` values('1000155','1852','0','���̹��','http://www.cafcw.cn/flv/1239775822354.flv');");
E_D("replace into `ysp` values('1000109','1879','6','ͩ�翴����','http://www.txfc.net/flv/1237969421931.flv');");
E_D("replace into `ysp` values('1000204','146','2','�������','http://www.tiefc.cn/flv/1244531749215.flv');");
E_D("replace into `ysp` values('1000162','314','0','�������','http://www.dgfce.cn/flv/1241574605608.flv');");
E_D("replace into `ysp` values('1000267','1754','5','����羰������','http://www.yxfcw.cn/flv/1249824570531.flv');");
E_D("replace into `ysp` values('1000163','299','0','�������','http://www.shenfc.cn/flv/1240997014704.flv');");
E_D("replace into `ysp` values('1000165','2246','0','�üҷ���','http://www.htfce.cn/flv/1247959851751.flv');");
E_D("replace into `ysp` values('1000167','309','0','������Ƶ','http://www.mzfce.cn/flv/1241553815561.flv');");
E_D("replace into `ysp` values('1000171','1488','55','ls','http://www.dsqfcw.com/flv/1243725036149.flv');");
E_D("replace into `ysp` values('1000169','241','2','���˻���','http://www.taifc.cn/flv/1241915709805.flv');");
E_D("replace into `ysp` values('1000170','241','1','��վ����','http://www.taifc.cn/flv/1241915980162.flv');");
E_D("replace into `ysp` values('1000238','1771','5','���п�','http://www.liyfc.cn/flv/1247150519574.flv');");
E_D("replace into `ysp` values('1000173','249','2','����Է����','http://www.zhzhfc.cn/flv/1242024950837.flv');");
E_D("replace into `ysp` values('1000272','1728','0','�Ϻ���ɽ����ɳ̲','http://www.jsf021.com/flv/1250076989837.flv');");
E_D("replace into `ysp` values('1000197','304','0','�ҵ�e�ҷ�������','http://www.jmfce.cn/flv/1243935123136.flv');");
E_D("replace into `ysp` values('1000189','1123','0','���ľ�ˮ��','http://www.dingzhou8.com/flv/1243580554568.flv');");
E_D("replace into `ysp` values('1000194','1488','33','zxsjhc','http://www.dsqfcw.com/flv/1243824917572.flv');");
E_D("replace into `ysp` values('1000196','1488','66','LS8mm','http://www.dsqfcw.com/flv/1243924622746.flv');");
E_D("replace into `ysp` values('1000264','1917','0','��������','http://www.yhfce.com/flv/1249351702222.flv');");
E_D("replace into `ysp` values('1000205','230','5','ŷʥ','http://www.fzhfc.cn/flv/1244624504565.flv');");
E_D("replace into `ysp` values('1000208','306','-1','123','http://www.mmfcw.cn/flv/1244728759357.flv');");
E_D("replace into `ysp` values('1000209','230','1','ŷʤʵ�ĵ���','http://www.fzhfc.cn/flv/1244880203406.flv');");
E_D("replace into `ysp` values('1000253','230','3','gjk','http://www.fzhfc.cn/flv/1248150285103.flv');");
E_D("replace into `ysp` values('1000212','1789','1','����','http://www.hmfcw.cn/flv/1245073932858.flv');");
E_D("replace into `ysp` values('1000213','1789','2','����ذ�','http://www.hmfcw.cn/flv/1245074046636.flv');");
E_D("replace into `ysp` values('1000216','1761','0','����ѵ�','http://www.pzfcw.cn/flv/1247540647566.flv');");
E_D("replace into `ysp` values('1000260','2225','0','xd','http://www.zhqfc.cn/flv/1249204788341.flv');");
E_D("replace into `ysp` values('1000223','1907','0','ԭ���Ƴ����1','http://www.lyfce.cn/flv/1245737147253.flv');");
E_D("replace into `ysp` values('1000255','1820','1','dfyj','http://www.gaoyfc.cn/flv/1248483893182.flv');");
E_D("replace into `ysp` values('1000233','304','0','�������','http://www.jmfce.cn/flv/1246876705583.flv');");
E_D("replace into `ysp` values('1000219','1826','0','��Ƶ�������','http://www.danyfc.cn/flv/1245661416531.flv');");
E_D("replace into `ysp` values('1000222','1789','3','�˽���ܰ԰','http://www.hmfcw.cn/flv/1245720907141.flv');");
E_D("replace into `ysp` values('1000224','1907','0','ԭ���Ƴ����2','http://www.lyfce.cn/flv/1245737193203.flv');");
E_D("replace into `ysp` values('1000225','1907','0','ԭ���Ƴ����3','http://www.lyfce.cn/flv/1245737231148.flv');");
E_D("replace into `ysp` values('1000237','250','6','�����³���λ','http://www.kaifc.cn/flv/1247032314491.flv');");
E_D("replace into `ysp` values('1000240','1771','3','���Ϸ�','http://www.liyfc.cn/flv/1247150915423.flv');");
E_D("replace into `ysp` values('1000241','1771','1','���Ϸ�2','http://www.liyfc.cn/flv/1247150998317.flv');");
E_D("replace into `ysp` values('1000243','249','3','���ⶫ���³�','http://www.zhzhfc.cn/flv/1247411802121.flv');");
E_D("replace into `ysp` values('1000245','1313','0','weihai','http://www.hmfc.cn/flv/1247496759406.flv');");
E_D("replace into `ysp` values('1000275','1810','2','���ӡ��','http://www.daffc.cn/flv/1251735938109.flv');");
E_D("replace into `ysp` values('1000252','230','0','uiui','http://www.fzhfc.cn/flv/1248089964438.flv');");
E_D("replace into `ysp` values('1000254','1771','7','��ȫʳ','http://www.liyfc.cn/flv/1248253828331.flv');");
E_D("replace into `ysp` values('1000256','1820','1','��԰��','http://www.gaoyfc.cn/flv/1248490309432.flv');");
E_D("replace into `ysp` values('1000257','1897','0','��Ƶ','http://www.dyfce.com/flv/1248508062766.flv');");
E_D("replace into `ysp` values('1000258','189','0','�������','http://www.sxfce.com/flv/1248869347342.flv');");
E_D("replace into `ysp` values('1000259','355','0','��վ����Ƭ','http://www.scdyf.cn/flv/1248923747629.flv');");
E_D("replace into `ysp` values('1000261','1810','3','ӥ���մ�30','http://www.daffc.cn/flv/1249187256316.flv');");
E_D("replace into `ysp` values('1000262','1810','5','ӥ���մ�24','http://www.daffc.cn/flv/1249203508725.flv');");
E_D("replace into `ysp` values('1000269','1787','1','զu','http://www.rgfcw.cn/flv/1249878765127.flv');");
E_D("replace into `ysp` values('1000271','1787','0','������','http://www.rgfcw.cn/flv/1249896671570.flv');");
E_D("replace into `ysp` values('1000273','230','6','fangchan','http://www.fzhfc.cn/flv/1251453088948.flv');");
E_D("replace into `ysp` values('1000274','138','1','�뵺����','http://www.fshfc.cn/flv/1251509228463.flv');");

require("../../inc/footer.php");
?>