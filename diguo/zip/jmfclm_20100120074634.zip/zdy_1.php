<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zdy`;");
E_C("CREATE TABLE `zdy` (
  `YID` int(10) NOT NULL auto_increment,
  `YXT` int(10) NOT NULL,
  `YYH` int(10) NOT NULL,
  `YLX` varchar(2) NOT NULL,
  `YFY` int(10) NOT NULL,
  PRIMARY KEY  (`YID`),
  KEY `YXT` (`YXT`),
  KEY `YYH` (`YYH`),
  KEY `YLX` (`YLX`)
) ENGINE=MyISAM AUTO_INCREMENT=1000346 DEFAULT CHARSET=gbk");
E_D("replace into `zdy` values('1000036','1000000','1000008','����','1001230');");
E_D("replace into `zdy` values('1000159','1000000','1000015','����','1002412');");
E_D("replace into `zdy` values('1000160','1000000','1000006','����','1003210');");
E_D("replace into `zdy` values('1000162','1000000','1000006','����','1000694');");
E_D("replace into `zdy` values('1000163','1000000','1000006','����','1000004');");
E_D("replace into `zdy` values('1000164','1000000','1000006','����','1000005');");
E_D("replace into `zdy` values('1000165','1000000','1000006','����','1003006');");
E_D("replace into `zdy` values('1000166','1000000','1000006','����','1003002');");
E_D("replace into `zdy` values('1000167','1000000','1000006','����','1003001');");
E_D("replace into `zdy` values('1000168','1000000','1000006','����','1002482');");
E_D("replace into `zdy` values('1000169','1000000','1000006','����','1001368');");
E_D("replace into `zdy` values('1000171','1000000','1000006','����','1001362');");
E_D("replace into `zdy` values('1000172','1000000','1000006','����','1001295');");
E_D("replace into `zdy` values('1000173','1000007','1000025','����','1023525');");
E_D("replace into `zdy` values('1000234','1000010','1000050','����','1046368');");
E_D("replace into `zdy` values('1000233','1000002','1000019','����','1024687');");
E_D("replace into `zdy` values('1000235','1000010','1000050','����','1044937');");

require("../../inc/footer.php");
?>