var util = (function(){
		var u = navigator.userAgent.toLowerCase();
		return {
				isIphone : function(){return (RegExp("iphone").test(u) || RegExp("ipod touch").test(u))},
				isIpad : function(){return RegExp("ipad").test(u)},
				isAndroid : function(){return (RegExp("android").test(u) || RegExp("android 2").test(u))},
				isMB : function(){return (util.isIphone() || util.isIpad() || util.isAndroid())}
		};
})();
window.util = util;
(function(){
		if( !util.isMB() ){
				//window.location.href = '../index.php';
		}
})();
